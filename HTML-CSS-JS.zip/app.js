 // Local storage variables
let userId = 'uniqueUserId';
let userCoins = parseInt(localStorage.getItem('userCoins')) || 0;
let checkInCount = parseInt(localStorage.getItem('checkInCount')) || 1;
let taskTimers = JSON.parse(localStorage.getItem('taskTimers')) || {};
let completedTasks = JSON.parse(localStorage.getItem('completedTasks')) || {};
let farmingActive = localStorage.getItem('farmingActive') === 'true' || false;
let farmingEndTime = farmingActive ? new Date(localStorage.getItem('farmingEndTime')) : null;
let farmingTimer;
let burnTimer;

// Save user data to local storage
function saveUserData() {
    localStorage.setItem('userCoins', userCoins);
    localStorage.setItem('checkInCount', checkInCount);
    localStorage.setItem('taskTimers', JSON.stringify(taskTimers));
    localStorage.setItem('completedTasks', JSON.stringify(completedTasks));
    localStorage.setItem('farmingActive', farmingActive);
    if (farmingEndTime) {
        localStorage.setItem('farmingEndTime', farmingEndTime.toString());
    }
}

// Load user data from local storage on page load
function loadUserData() {
    document.getElementById('coinAmount').innerText = userCoins;
    document.getElementById('checkInStatus').innerText = `Checked in ${checkInCount} times`;

    // Load task timers and completed tasks
    for (const [taskId, timer] of Object.entries(taskTimers)) {
        const taskButton = document.getElementById(taskId).getElementsByTagName('button')[0];
        if (completedTasks[taskId]) {
            taskButton.innerText = 'Completed';
            taskButton.disabled = true; // Disable button if task is completed
        } else {
            taskButton.innerText = `${timer} seconds...`;
        }
    }

    // If farming was active, resume the countdown
    if (farmingActive) {
        startFarming(true); // Resume farming countdown
    }
}

// Show home page
function showHomePage() {
    document.getElementById('homePage').style.display = 'flex';
    document.getElementById('taskPage').style.display = 'none';
    document.getElementById('friendsPage').style.display = 'none';
    loadUserData(); // Load user data when showing home page
}

// Show task page
function showTaskPage() {
    document.getElementById('homePage').style.display = 'none';
    document.getElementById('taskPage').style.display = 'flex';
    document.getElementById('friendsPage').style.display = 'none';
}

// Show friends page
function showFriendsPage() {
    document.getElementById('homePage').style.display = 'none';
    document.getElementById('taskPage').style.display = 'none';
    document.getElementById('friendsPage').style.display = 'flex';
}

// Start or resume farming
function startFarming(resume = false) {
    const farmingButton = document.getElementById("farmingButton");
    const countdownElement = document.getElementById("burnCountdown");

    console.log("Start farming called. Is farming active?", farmingActive);

    if (!resume && farmingActive) {
        console.log("Farming is already active. Exiting startFarming.");
        return; // Prevent starting again if already active
    }

    if (!farmingActive) {
        farmingActive = true;
        let now = new Date();
        farmingEndTime = new Date(now.getTime() + 6 * 60 * 60 * 1000); // 6 hours from now
        localStorage.setItem('farmingEndTime', farmingEndTime.toString());
        console.log("Farming started. End time:", farmingEndTime);
    }

    farmingButton.disabled = true;

    // Update countdown every second
    farmingTimer = setInterval(() => {
        const now = new Date();
        let remainingTime = new Date(farmingEndTime) - now;

        if (remainingTime > 0) {
            let countdown = Math.floor(remainingTime / 1000); // Time left in seconds
            const hours = Math.floor(countdown / 3600);
            const minutes = Math.floor((countdown % 3600) / 60);
            const seconds = countdown % 60;

            countdownElement.innerHTML = `Farming... ${hours}h ${minutes}m ${seconds}s left`;
        } else {
            clearInterval(farmingTimer);
            farmingActive = false;
            farmingEndTime = null; // Clear farming end time
            userCoins += 5; // Add coins after farming
            saveUserData(); // Save updated coins and reset farming
            document.getElementById('farmingButton').innerText = 'Claim'; // Change button to Claim
            document.getElementById("claimContainer").style.display = "block";
        }

        saveUserData(); // Save progress every second
    }, 1000);
}

// Claim Rewards Functionality
function claimRewards() {
    document.getElementById("claimContainer").style.display = "none";
    userCoins += 5;  // Add 5 $ACE
    document.getElementById("coinAmount").textContent = userCoins;
    saveUserData();
    alert('You claimed 5 $ACE!');
}

// Start burn timer
function startBurnTimer() {
    let burnTime = 60 * 60; // 1 hour in seconds
    document.getElementById('burnCountdown').innerText = `Burns in: ${formatTime(burnTime)}`;
    burnTimer = setInterval(() => {
        burnTime--;
        document.getElementById('burnCountdown').innerText = `Burns in: ${formatTime(burnTime)}`;
        if (burnTime <= 0) {
            clearInterval(burnTimer);
            userCoins = Math.floor(userCoins * 0.5); // Burn 50% of coins
            saveUserData(); // Save burned coins to local storage
            alert('Coins burned after 1 hour!');
            document.getElementById('burnCountdown').innerText = '';
        }
    }, 1000);
}

// Format time for display
function formatTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

// Check-in system
function checkIn() {
    checkInCount++;
    userCoins += 3 + Math.floor(checkInCount / 5); // Reward increases every 5 check-ins
    document.getElementById('coinAmount').innerText = userCoins;
    document.getElementById('checkInStatus').innerText = `Checked in ${checkInCount} times`;
    saveUserData(); // Save check-in progress to local storage
}

// Task Countdown for completion (1 minute) with reward
function startTask(taskId, link) {
    const countdownElement = document.getElementById(`taskCountdown${taskId.slice(-1)}`);
    let countdown = 60;  // 1 minute in seconds

    const taskInterval = setInterval(() => {
        countdownElement.innerHTML = `Task in progress... ${countdown} seconds left`;
        countdown--;
        taskTimers[taskId] = countdown; // Save task countdown progress
        saveUserData(); // Save task progress every second

        if (countdown <= 0) {
            clearInterval(taskInterval);
            userCoins += 7; // Reward for task
            document.getElementById('coinAmount').innerText = userCoins;
            countdownElement.innerHTML = 'Task completed! 7 $ACE added.';
            completedTasks[taskId] = true; // Mark task as completed
            document.querySelector(`[data-task-id="${taskId}"] button`).innerText = 'Completed';
            document.querySelector(`[data-task-id="${taskId}"] button`).disabled = true;
            saveUserData(); // Save task completion and reward
            window.open(link, '_blank'); // Open task link
        }
    }, 1000);
}

// Initialize the app
window.onload = () => {
    loadUserData(); 
    showHomePage(); 

    const farmingButton = document.getElementById('farmingButton');
    console.log(farmingButton); // Check if this logs the button correctly

    if (farmingButton) {
        farmingButton.addEventListener('click', () => startFarming());
    }

    const checkInButton = document.getElementById('checkInButton');
    if (checkInButton) {
        checkInButton.addEventListener('click', checkIn);
    }

    const copyReferralButton = document.getElementById('copyReferralButton');
    if (copyReferralButton) {
        copyReferralButton.addEventListener('click', copyReferralLink);
    }

    // Add event listeners for task buttons dynamically if you have multiple tasks
    addTaskEventListeners();
};

// Add event listeners for task buttons
function addTaskEventListeners() {
    const taskButtons = document.querySelectorAll('.task-button'); // Assume task buttons have this class
    taskButtons.forEach(button => {
        const taskId = button.dataset.taskId; // Assume each button has a data attribute for the task ID
        const link = button.dataset.link; // Assume each button has a data attribute for the task link
        button.addEventListener('click', () => startTask(taskId, link));
    });
}

// Copy referral link to clipboard
function copyReferralLink() {
    const referralLink = document.getElementById('referralLink');
    referralLink.select();
    document.execCommand('copy');
    alert('Referral link copied!');
}